#Plugin Name: boxberry-delivery (boxdev)
* Plugin URI: https://github.com/Nemolite/boxberry-delivery
* Description: Отправка и получение данных о заказах на Boxberry 
* Version: 1.0.0
* Author: Nemolite
* Author URI: http://vandraren.ru/
* License: GPL2
